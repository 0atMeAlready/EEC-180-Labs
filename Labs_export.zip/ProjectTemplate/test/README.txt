Save all testbench .v files here. In this manner, shared testbenches may be accessed by all ModelSim projects in the lab exercise. 

Why share a testbench? 

It is common for multiple design variants with competing performance metrics to use a common testbench for functional verification as the variants should be functionally equivalent.